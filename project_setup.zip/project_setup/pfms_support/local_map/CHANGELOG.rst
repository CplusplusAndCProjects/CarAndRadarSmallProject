^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package local_map
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.8 (2015-01-21)
------------------
* Unchanged

0.1.2 (2015-01-14)
------------------
* local_map: fix message_runtime in catkin_package
* Contributors: Gaël Ecorchard

0.1.1 (2015-01-12)
------------------
* First public release for Indigo
* Contributors: Gaël Ecorchard
