^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package map_ray_caster
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.8 (2015-01-21)
------------------
* Unchanged

0.1.1 (2015-01-12)
------------------
* First public release for Indigo
* Contributors: Gaël Ecorchard
